/* Copyright 1991 Digital Equipment Corporation.
** All Rights Reserved.
*****************************************************************/

extern long interrupted;

/* global functions */

void handle_interrupt(void);
void init_interrupt(void);
void interrupt(void);
