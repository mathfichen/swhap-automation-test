/* 
 * Copyright 1991 Digital Equipment Corporation.
 * All Rights Reserved.
 */


/*
** list.h contains the functions to manage double link list
** with 2 entries (first and last element)
** Links belongs to each atom
*/


#ifndef NULL
#define NULL 0
#endif
#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

typedef void *			Ref;
typedef struct wl_ListLinks *	RefListLinks;
typedef struct wl_ListHeader *	RefListHeader;
typedef RefListLinks		(*RefListGetLinksProc)	( );
typedef int			(*RefListEnumProc)	( );



/*
  "First", "Last" are pointers to the first and last element of the list
  respectively.
  
  "Current" points to the current processed element of the list. Used when
  applying a function to each element of the list.
  
  "GetLinks" is a function to get the list links on the object.
  
  "Lock" is the number of recursive enum calls on the list. Used only in
  debugging mode.
  */


typedef struct wl_ListHeader
{
  Ref First, Last;

#ifdef prlDEBUG
    Int32			Lock;
#endif

    RefListGetLinksProc		GetLinks;
} ListHeader;



typedef struct wl_ListLinks
{
    Ref Next, Prev;
} ListLinks;



/* global functions */

void List_Append(RefListHeader header,Ref atom);
long List_Card(RefListHeader header);
void List_Concat(RefListHeader header1,RefListHeader header2);
long List_CountAtom(Ref p,Ref nbR);
void List_Cut(RefListHeader header,Ref atom,RefListHeader newHeader);
long List_Enum(RefListHeader header,RefListEnumProc proc,Ref closure);
long List_EnumBack(RefListHeader header,RefListEnumProc proc,Ref closure);
long List_EnumBackFrom(RefListHeader header,Ref atom,RefListEnumProc proc,
                       Ref closure);
long List_EnumFrom(RefListHeader header,Ref atom,RefListEnumProc proc,
                   Ref closure);
void List_InsertAfter(RefListHeader header,Ref atom,Ref mark);
void List_InsertAhead(RefListHeader header,Ref atom);
void List_InsertBefore(RefListHeader header,Ref atom,Ref mark);
long List_IsUnlink(RefListLinks links);
void List_Remove(RefListHeader header,Ref atom);
void List_Reverse(RefListHeader header);
void List_SetLinkProc(RefListHeader header, RefListGetLinksProc getLinks);
void List_Swap(RefListHeader header,Ref first,Ref second);
long List_SwapLinks(RefListHeader header,Ref atom);


/*=============================================================================*/
/*			Get functions	(macros)                               */
/*=============================================================================*/

#define List_First(header) ((header)->First)
#define List_Last(header) ((header)->Last)
#define List_Next(header,RefAtom) ((*(header)->GetLinks)(RefAtom)->Next)
#define List_Prev(header,RefAtom) ((*(header)->GetLinks)(RefAtom)->Prev)
#define List_IsEmpty(header) (List_First(header)==NULL)
