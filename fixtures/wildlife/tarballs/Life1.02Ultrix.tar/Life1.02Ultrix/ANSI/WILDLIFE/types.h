/* Copyright 1991 Digital Equipment Corporation.
** All Rights Reserved.
*****************************************************************/

#ifndef _TYPES_H_
#define _TYPES_H_

/* global functions */

void assert_args_not_eval(ptr_node n);
void assert_attributes(ptr_psi_term t);
void assert_complicated_type(ptr_psi_term);
void assert_delay_check(ptr_node n);
void assert_protected(ptr_node n,long prot);
void assert_type(ptr_psi_term);
long bit_length(ptr_int_list c);
ptr_int_list copyTypeCode(ptr_int_list u);
ptr_int_list decode(ptr_int_list);
void encode_types(void);
long glb(ptr_definition, ptr_definition, ptr_definition*, ptr_int_list*);
long glb_code(long, GENERIC, long, GENERIC, long*, GENERIC*);
long glb_value(long, long, GENERIC, GENERIC, GENERIC, GENERIC*);
void inherit_always_check(void);
long matches(ptr_definition,ptr_definition,long*);
void or_codes(ptr_int_list u,ptr_int_list v);
long overlap_type(ptr_definition, ptr_definition);
void print_codes(void);
void print_def_type(def_type t);
long redefine(ptr_psi_term);
long sub_CodeType(ptr_int_list c1,ptr_int_list c2);
long sub_type(ptr_definition, ptr_definition);

extern long types_modified;
extern long type_count;

#endif
