/* Copyright 1991 Digital Equipment Corporation.
** All Rights Reserved.
*****************************************************************/

#ifdef X11

#include "list.h"

#define xDefaultFont -1
#define xDefaultLineWidth -1

typedef enum {DRAW_LINE, DRAW_RECTANGLE, DRAW_ARC, DRAW_POLYGON,
	      FILL_RECTANGLE, FILL_ARC, FILL_POLYGON,
              DRAW_STRING, DRAW_IMAGE_STRING} Action;


/* global functions */

ListHeader* x_display_list(void);
void x_free_display_list(ListHeader *displaylist);
long x_postscript_window(Display *display,Window window,ListHeader *displaylist,
                         const char *filename);
void x_record_arc(ListHeader *displaylist, Action action, long x, long y,
                  long width, long height, long startangle, long arcangle,
                  unsigned long function, unsigned long color,
                  unsigned long linewidth);
void x_record_line(ListHeader *displaylist, Action action, long x0, long y0,
                   long x1, long y1, unsigned long function, unsigned long color,
                   unsigned long linewidth);
void x_record_polygon(ListHeader *displaylist, Action action, XPoint *points,
                      long npoints, unsigned long function, unsigned long color,
                      unsigned long linewidth);
void x_record_rectangle(ListHeader *displaylist, Action action, long x, long y,
                        long width, long height, unsigned long function,
                        unsigned long color, unsigned long linewidth);
void x_record_string(ListHeader *displaylist, Action action, long x, long y,
                     const char *str, long font, unsigned long function,
                     unsigned long color);
void x_refresh_window(Display *display,Window window,Pixmap pixmap,GC pixmapgc,
                      ListHeader *displaylist);
void x_set_gc (Display *display,GC gc,long function,unsigned long color,
               long linewidth,Font font);


#endif
