/* Copyright 1991 Digital Equipment Corporation.
** All Rights Reserved.
**
** Last modified on Wed Jan 27 00:41:03 1993 by Rmeyer
**      modified on Fri Sep  6 14:17:04 1991 by vanroy
**      modified on Fri Aug 23 16:36:08 1991 by herve 
*****************************************************************/

/* global functions */

void bk_mark_quote(ptr_psi_term t);
void clear_copy(void);
ptr_psi_term distinct_copy(ptr_psi_term t);
ptr_node distinct_tree(ptr_node t);
ptr_psi_term eval_copy(ptr_psi_term t,long heap_flag);
ptr_psi_term exact_copy(ptr_psi_term t,long heap_flag);
ptr_psi_term inc_heap_copy(ptr_psi_term t);
void init_copy(void);
void insert_translation(ptr_psi_term a,ptr_psi_term b,long info);
void mark_eval(ptr_psi_term t);
void mark_nonstrict(ptr_psi_term t);
void mark_quote(ptr_psi_term t);
ptr_psi_term quote_copy(ptr_psi_term t,long heap_flag);
ptr_psi_term translate(ptr_psi_term a,long **infoptr);
