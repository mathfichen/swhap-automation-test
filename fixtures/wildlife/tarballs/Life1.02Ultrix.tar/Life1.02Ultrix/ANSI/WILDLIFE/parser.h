/* Copyright 1991 Digital Equipment Corporation.
** All Rights Reserved.
*****************************************************************/

extern long parse_ok;

psi_term parse(long *q);
ptr_psi_term stack_copy_psi_term(psi_term t);
