/* Copyright 1991 Digital Equipment Corporation.
** All Rights Reserved.
*****************************************************************/

/* global functions */

long abort_life(int nlflag);
long c_abort(void);
ptr_psi_term collect_symbols(long sel);
void exit_life(int nlflag);
long get_real_value(ptr_psi_term t,REAL *v,long *n);
long hidden_type(ptr_definition t);
void init_built_in_types(void);
void insert_math_builtins(void);                 /* from bi_math.c */
void insert_system_builtins(void);               /* from bi_system.c */
void insert_type_builtins(void);                 /* from bi_type.c */
long isSubTypeValue(ptr_psi_term arg1, ptr_psi_term arg2); /* bi_type.c */
int isValue(ptr_psi_term p);                     /* from bi_type.c */
ptr_int_list lub(ptr_psi_term a,ptr_psi_term b,ptr_psi_term *pp); /* from lub.c*/
void new_built_in(ptr_module m,const char *s,def_type t,long (*r)());
ptr_psi_term stack_cons(ptr_psi_term head,ptr_psi_term tail);
ptr_psi_term stack_nil(void);
void unify_bool_result(ptr_psi_term t,long v);
long unify_real_result(ptr_psi_term t,REAL v);




/* used by collect_symbols */

#define least_sel 0
#define greatest_sel 1
#define op_sel 2

ptr_psi_term makePsiTerm ARGS((ptr_definition x));
ptr_psi_term makePsiList ARGS((GENERIC head, ptr_psi_term (*valueFunc)(), \
                               GENERIC (*nextFunc)()));

/* functions for accessing next and value fields of some structures */

