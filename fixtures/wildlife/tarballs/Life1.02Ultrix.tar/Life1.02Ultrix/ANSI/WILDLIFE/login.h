/* Copyright 1991 Digital Equipment Corporation.
** All Rights Reserved.
*****************************************************************/

/* High level calls */
void assert_clause(ptr_psi_term);

/* Low level calls */
void add_rule(ptr_psi_term head,ptr_psi_term body,def_type typ);
void push_goal(goals,ptr_psi_term,ptr_psi_term,GENERIC);
void fetch_def(ptr_psi_term,long);
void get_one_arg(ptr_node,ptr_psi_term*);
void get_one_arg_addr(ptr_node,ptr_psi_term**);
void get_two_args(ptr_node,ptr_psi_term*,ptr_psi_term*);
void merge_unify(ptr_node*,ptr_node);
void fetch_def_lazy(ptr_psi_term,ptr_definition,ptr_definition,ptr_node,
                    ptr_node,long,long);

/* Choice points and trailing */
void push_choice_point(goals,ptr_psi_term,ptr_psi_term,GENERIC);
extern ptr_stack undo_stack;
void push_ptr_value(type_ptr,GENERIC*);
void push_ptr_value_global(type_ptr,GENERIC*);
void push2_ptr_value(type_ptr,GENERIC*,GENERIC);
void push_window(long,long,long);
void clean_undo_window(long,long);

#ifdef TS
void push_psi_ptr_value(ptr_psi_term,GENERIC*); /* 9.6 */
extern unsigned long global_time_stamp; /* 9.6 */
/* Trail if q was last modified before the topmost choice point */
#define TRAIL_CONDITION(Q) (choice_stack && \
                            choice_stack->time_stamp>=Q->time_stamp)
#endif

/* Detrailing */
void undo(ptr_stack);
void undo_actions(void);

/* User-interface */
extern long stepflag;
extern long ignore_eff;
extern long goal_count;
void show_count(void);
extern struct tms start_time,end_time;

int dummy_printf(const char *f,const char *s,const char *t);
void main_prove(void);
void reset_stacks(void);
void start_chrono(void);

