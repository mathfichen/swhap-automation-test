/* Copyright 1991 Digital Equipment Corporation.
** All Rights Reserved.
*****************************************************************/

/* global functions */

GENERIC heap_alloc(long);
GENERIC stack_alloc(long);

void garbage(void);
void init_memory(void);
long memory_check(void);

void fail_all(void);

char *GetStrOption(const char*,char*);
int GetBoolOption(const char*);
int GetIntOption(const char*,int);
