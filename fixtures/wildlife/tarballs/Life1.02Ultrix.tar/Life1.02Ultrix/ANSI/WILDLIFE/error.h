/* Copyright 1991 Digital Equipment Corporation.
** All Rights Reserved.
**
*****************************************************************/

#ifndef _ERROR_H_
#define _ERROR_H_


void stack_info(FILE*);

void init_trace(void);
void reset_step(void);
void tracing(void);
void new_trace(long);
void new_step(long);
long reportAndAbort(ptr_psi_term g,const char *s);
void toggle_trace(void);
void toggle_step(void);
void set_trace_to_prove(void);

extern long quietflag; /* 21.1 */
extern long trace;
extern long verbose; /* 21.1 */
extern long stepflag;
extern long steptrace;
extern long stepcount;

#define NOTQUIET (!quietflag || verbose) /* 21.1 */

long warning(void);
long warningx(void);
void perr(const char*);
void perr_s(const char*,const char*);
void perr_s2(const char*,const char*,const char*);
void perr_i(const char*,long);

void report_error(ptr_psi_term,const char*);
void report_warning(ptr_psi_term,const char*);
void report_error2(ptr_psi_term,const char*);
void report_warning2(ptr_psi_term,const char*);

void nonnum_warning(ptr_psi_term,ptr_psi_term,ptr_psi_term);
long bit_and_warning(ptr_psi_term,REAL);
long bit_or_warning(ptr_psi_term,REAL);
long bit_not_warning(ptr_psi_term,REAL);
long int_div_warning(ptr_psi_term,REAL);
long mod_warning(ptr_psi_term,REAL,int);
long shift_warning(long,ptr_psi_term,REAL);

#ifndef NOTRACE
#define Traceline  if (trace) traceline
#else
#define Traceline  if (0) traceline
#endif

/* 21.1 */
#define Infoline   if (NOTQUIET) infoline

/* copy from extern.h */

#ifndef VarArgBaseDecl
#ifdef m88k
#define VarArgBaseDecl	va_type va_alist
#else
#define VarArgBaseDecl	long va_alist
#endif
#endif

/* a trick to make variable number of arguments work with ANSI C */
#ifdef _ERROR_C
/* these prototypes are visible inside error.c */
void Errorline(const char*,VarArgBaseDecl);
void Syntaxerrorline(const char*,VarArgBaseDecl);
void warningline(const char*,VarArgBaseDecl);
void outputline(const char*,VarArgBaseDecl);
void infoline(const char*,VarArgBaseDecl);
void traceline(const char*,VarArgBaseDecl);
#else
/* these prototypes are visible outside error.c */
void Errorline(const char*,...);
void Syntaxerrorline(const char*,...);
void warningline(const char*,...);
void outputline(const char*,...);
void infoline(const char*,...);
void traceline(const char*,...);
#endif

#define Warningline if (warningflag) warningline

#endif
