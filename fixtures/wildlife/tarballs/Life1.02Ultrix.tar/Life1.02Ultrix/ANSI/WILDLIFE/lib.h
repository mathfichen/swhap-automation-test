/* lib.h */

/* global functions */

void exit_if_true(long exitflag);
void init_io(void);
