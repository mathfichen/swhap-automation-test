/* Copyright 1991 Digital Equipment Corporation.
** All Rights Reserved.
*****************************************************************/


typedef struct wl_tab_brk *       ptr_tab_brk;
typedef struct wl_item *          ptr_item;

typedef struct wl_tab_brk {
  long column;
  long broken;
  long printed;
} tab_brk;

typedef struct wl_item {
  char *str;
  ptr_tab_brk tab;
} item;

void init_print(void);
void listing_pred_write(ptr_node,long);
long str_to_int(char*);

void prettyf(const char*);
void prettyf_quote(const char*);

long print_variables(long);
void print_resid_message(ptr_psi_term,ptr_resid_list);
void print_operator_kind(FILE*,operator);
void pred_write(ptr_node n);

void display_psi(FILE*,ptr_psi_term);
void display_psi_stdout(ptr_psi_term);
void display_psi_stream(ptr_psi_term);
void display_psi_stderr(ptr_psi_term);

void print_code(FILE*,ptr_int_list);

extern const char *no_name;
extern char *buffer;

/* Global flags that modify how writing is done. */
extern long print_depth;
extern long indent;
extern long const_quote;
extern long write_stderr;
extern long write_corefs;
extern long write_resids;
extern long write_canon;
