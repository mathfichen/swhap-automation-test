/* Copyright 1991 Digital Equipment Corporation.
** All Rights Reserved.
*****************************************************************/

#ifdef X11

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>

extern ptr_psi_term xevent_list, xevent_existing;

extern ptr_definition
  xevent, xkeyboard_event, xbutton_event, /* RM: 7.12.92 */
  xexpose_event, xdestroy_event, xmotion_event,
  xdisplay, xdrawable, xwindow, xpixmap, xconfigure_event,
  xenter_event,xleave_event, xmisc_event,  /* RM: 3rd May 93 */
  xgc, xdisplaylist;

extern long x_window_creation;

/* global functions */

void x_setup_builtins(void);
long x_exist_event(void);
long x_read_stdin_or_event(long *ptreventflag);
void x_destroy_window(Display *display,Window window);
void x_hide_window(Display *display, long window);
long GetIntAttr(ptr_psi_term psiTerm,const char *attributeName);
void x_show_window(Display *display,long window);
void x_show_subwindow(Display *display, long window);
void x_hide_subwindow(Display *display, long window);

#endif
