/* Copyright 1991 Digital Equipment Corporation.
** All Rights Reserved.
*****************************************************************/


#define deref(P)         {deref_ptr(P);if (deref_eval(P)) return TRUE;}
#define deref_void(P)    {deref_ptr(P);deref_eval(P);}
#define deref_rec(P)     {deref_ptr(P);if (deref_rec_eval(P)) return TRUE;}
#define deref_args(P,S)  {deref_ptr(P);if (deref_args_eval(P,S)) return TRUE;}
#define deref_args_void(P)  {deref_ptr(P);deref_args_eval(P);}

/* Set constants for deref_args */
#define set_empty    0
#define set_1        1
#define set_2        2
#define set_1_2      3
#define set_1_2_3    7
#define set_1_2_3_4 15

extern ptr_goal resid_aim;
extern ptr_resid_list resid_vars; /* 21.9 */
extern ptr_goal resid_limit;
extern long curried;
extern long can_curry;

typedef struct wl_resid_block *ptr_resid_block;

typedef struct wl_resid_block {
   long cc_cr; /* 11.9 */
   ptr_goal ra;
   /* long cc; 11.9 */
   /* long cr; 11.9 */
   ptr_resid_list rv; /* 21.9 */
   ptr_psi_term md;
} resid_block;


/* global functions */

void curry(void);
long deref_args_eval(ptr_psi_term t,long set);
long deref_eval(ptr_psi_term t);
long deref_rec_eval(ptr_psi_term t);
void deref2_eval(ptr_psi_term t);
void deref2_rec_eval(ptr_psi_term t);
void do_currying(void);
long do_residuation_user(void);
long eval_aim(void);
long i_check_out(ptr_psi_term t);
long i_eval_args(ptr_node n);
void init_global_vars(void);
long match_aim(void);
void release_resid(ptr_psi_term t);
void release_resid_notrail(ptr_psi_term t);
void residuate(ptr_psi_term t);
long residuateGoalOnVar(ptr_goal g,ptr_psi_term var,ptr_psi_term othervar);
void residuate2(ptr_psi_term u,ptr_psi_term v);
void residuate3(ptr_psi_term u,ptr_psi_term v,ptr_psi_term w);
void restore_resid(ptr_resid_block rb,ptr_psi_term *match_date);
void save_resid(ptr_resid_block rb,ptr_psi_term match_date);
