/* Copyright 1991 Digital Equipment Corporation.
** All Rights Reserved.
*****************************************************************/


void raw_setup_builtins(void);

int bcopy(void*,void*,int); /* just a guess */
int ioctl(long,long,void*);
int setvbuf(FILE*,char*,int,size_t);
int bzero(char*,long);
long select(long,fd_set*,fd_set*,fd_set*,struct timeval*);
int interrupt(void);
