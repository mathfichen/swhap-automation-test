/* modules.h */

/* global functions */

void init_modules(void);
ptr_module set_current_module(ptr_module);
ptr_definition update_symbol(ptr_module,const char*);
ptr_module create_module(const char*);
char *make_module_token(ptr_module,const char*);
ptr_module extract_module_from_name(const char*);
const char *strip_module_name(const char *str);
char *print_symbol(ptr_keyword);
void pretty_symbol(ptr_keyword);
void pretty_quote_symbol(ptr_keyword);
ptr_module find_module(const char*);
ptr_definition update_feature(ptr_module,char*);

int global_unify(ptr_psi_term u,ptr_psi_term v);

long all_public_symbols(void);
long c_set_module(void);
long c_open_module(void);
long c_public(void);
long c_private(void);
long c_private_feature(void);
long c_display_modules(void);
long c_display_persistent(void); /*  RM: Feb 12 1993  */
long c_trace_input(void);
long c_replace(void);
long c_current_module(void);
long c_alias(void); /*  RM: Feb 22 1993  */
int get_module(ptr_psi_term,ptr_module*); /*  RM: Mar 11 1993  */

extern ptr_module bi_module;      /* Module for public built-ins */
extern ptr_module user_module;    /* Default module for user input */
extern ptr_module no_module;     
extern ptr_module x_module;       /* '#ifdef X11' unnecessary  */
extern ptr_module syntax_module;  /* Module for minimal Prolog syntax */
extern ptr_node module_table;     /* The table of modules */
extern ptr_module current_module; /* The current module for the tokenizer */

extern long display_modules;
extern long display_persistent;

extern long trace_input;
