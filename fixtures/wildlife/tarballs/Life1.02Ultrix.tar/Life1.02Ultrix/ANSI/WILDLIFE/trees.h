/* Copyright 1991 Digital Equipment Corporation.
** All Rights Reserved.
*****************************************************************/

typedef long (*comp_f)(const void*,const void*);


char *heap_copy_string(const char*);
char *stack_copy_string(const char*);

ptr_node heap_insert(comp_f comp,char*,ptr_node*,GENERIC);
ptr_node stack_insert(comp_f comp,char*,ptr_node*,GENERIC);
ptr_node bk_stack_insert(comp_f comp,char*,ptr_node*,GENERIC);
ptr_node bk2_stack_insert(comp_f comp,char*,ptr_node*,GENERIC);
void heap_insert_copystr(char*,ptr_node*,GENERIC);
void stack_insert_copystr(char*,ptr_node*,GENERIC);
void delete_attr(char*,ptr_node*);

ptr_node find(comp_f comp,const char *keystr,ptr_node tree);

long intcmp(long,long);
long featcmp(const char*,const char*);

ptr_node find_data(GENERIC,ptr_node);
