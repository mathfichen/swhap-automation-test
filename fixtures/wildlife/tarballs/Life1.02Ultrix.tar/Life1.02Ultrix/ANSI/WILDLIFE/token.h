/* Copyright 1991 Digital Equipment Corporation.
** All Rights Reserved.
*****************************************************************/



extern long stdin_terminal;
extern long var_occurred;

/* Part of global input file state */
extern long line_count;
extern long start_of_line;
extern long saved_char;
extern long old_saved_char;
extern ptr_psi_term saved_psi_term;
extern ptr_psi_term old_saved_psi_term;
extern long eof_flag;
extern FILE *input_stream;

/* File state ADT */
extern ptr_psi_term input_state;
extern ptr_psi_term stdin_state;

/* Names of the features */
#define STREAM "stream"
#define INPUT_FILE_NAME "input_file_name"
#define LINE_COUNT "line_count"
#define START_OF_LINE "start_of_line"
#define SAVED_CHAR "saved_char"
#define OLD_SAVED_CHAR "old_saved_char"
#define SAVED_PSI_TERM "saved_psi_term"
#define OLD_SAVED_PSI_TERM "old_saved_psi_term"
#define EOF_FLAG "eof_flag"
#define CURRENT_MODULE "current_module"



/* For parsing from a string */
extern long stringparse;
extern char *stringinput;

/* Parser/tokenizer state handling */

typedef struct wl_parse_block *ptr_parse_block;

typedef struct wl_parse_block {
  long lc;
  long sol;
  long sc;
  long osc;
  ptr_psi_term spt;
  ptr_psi_term ospt;
  long ef;
} parse_block;


/* global functions */

void begin_terminal_io(void);
void end_terminal_io(void);
char *expand_file_name(char *s);
GENERIC get_attr(ptr_psi_term t,const char *attrname);
FILE *get_stream(ptr_psi_term t);
void init_parse_state(void);
long legal_in_name(long c);
long open_input_file(char *file);
long open_output_file(char* file);
void psi_term_error(void);
void put_back_char(long c);
void put_back_token(psi_term t);
long read_char(void);
void read_token(ptr_psi_term tok);
void read_token_b(ptr_psi_term tok);
void restore_parse_state(ptr_parse_block pb);
void restore_state(ptr_psi_term t);
void save_parse_state(ptr_parse_block pb);
void save_state(ptr_psi_term t);
void stack_add_int_attr(ptr_psi_term t,const char *attrname,long value);
void stack_add_psi_attr(ptr_psi_term t,const char *attrname,ptr_psi_term g);
void stdin_cleareof(void);
