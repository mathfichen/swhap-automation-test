/* Copyright 1994 Peter Van Roy.
** All Rights Reserved.
** Portions of this code Copyright Seth Copen Goldstein
*****************************************************************/

#include "extern.h"
#include "login.h"
#include "trees.h"
#include "print.h"
#include "memory.h"
#include "error.h"
#include "token.h"


/* Make a decoded type list containing one type */
static ptr_int_list makeUnitList(x)
ptr_definition x;
{
  ptr_int_list ans;

  ans = STACK_ALLOC(int_list);
  ans->value = (GENERIC) x;
  ans->next = NULL;
  return ans;
}


/* Given a type t and a current list of types ans that
   represents the decoding of pattern, augment ans with t
   if necessary and remove redundancy from ans.
*/
static void check_and_traverse_parents(t, ans, pattern, flags)
ptr_definition t;
ptr_int_list *ans; /* list of ptr_definition */
ptr_int_list pattern; /* code */
long *flags;
{
   ptr_int_list ans_index;
   ptr_int_list *prev_ans_index;
   int add_t;
   ptr_int_list par;
   int len;

   /* Visit each type only once */
   len = bit_length(t->code);
   Traceline("flags[%d]==%d\n",len,flags[len]);
   if (flags[len]) return;
   flags[len]=TRUE;

   /* Run through all types in the current answer */
   ans_index = *ans;
   prev_ans_index = ans;
   Traceline("sub_CodeType(%C,%C)\n",pattern,t->code);
   if (ans_index==NULL) {
     add_t = sub_CodeType(pattern,t->code);
   } else {
     add_t=FALSE;
     if (sub_CodeType(pattern,t->code)) {
       add_t = TRUE;
       while (ans_index) {
         ptr_int_list ticode = ((ptr_definition) ans_index->value)->code;
  
         /* If t->code is lower than ticode then remove ticode from answer list */
         if (sub_CodeType(t->code,ticode)) {
           *prev_ans_index = ans_index->next;
         }
         /* If there doesn't exist a lower type than t, then add t */
         if (add_t && sub_CodeType(ticode,t->code)) add_t = FALSE;

         prev_ans_index = &(ans_index->next);
         ans_index = ans_index->next;
       }
     }
   }

   if (add_t) {
     /* Add type t to the answer */
     ptr_int_list new_ans;
     new_ans = STACK_ALLOC(int_list);
     new_ans->value = (GENERIC) t;
     new_ans->next = *ans;
     *ans = new_ans;
   }

   /* Do the same for the parents of t */
   par = t->parents;
   while (par) {
     check_and_traverse_parents((ptr_definition)par->value, ans, pattern, flags);
     par = par->next;
   }
}


/* Return a decoded type list of the root sorts that make up the least upper
   bound of the terms a and b.  Deal with special cases (integers, strings, etc).
*/
ptr_int_list lub(a,b,pp)
ptr_psi_term a;
ptr_psi_term b;
ptr_psi_term *pp;
{
  extern long type_count; /* the number of sorts in the hierarchy */
  ptr_definition ta;      /* type of psi term a */
  ptr_definition tb;      /* type of psi term b */
  long *flags;            /* set to 1 if this type has been checked in the lub search */
  ptr_int_list ans; /* list of ptr_definition */
  ptr_int_list pattern;
  long found;
  
  ta = a->type;
  tb = b->type;
  
  /**** Handle the special cases: ****/
  
  if (isValue(a) && isValue(b) && sub_type(ta,tb) && sub_type(tb,ta))
  {
    /* Special case of two values being of same type.  Check that they */
    /* might actually be same value before returning the type. */
    if (isSubTypeValue(a, b))
    {
      /* Since we already know they are both values, isSubTypeValue */
      /* returns TRUE if they are same value, else false. */
      *pp = a;
      return NULL;
    }
  }
  
  if (sub_type(ta, tb)) return makeUnitList(tb);
  if (sub_type(tb, ta)) return makeUnitList(ta);

  if (ta->code==NOT_CODED || tb->code==NOT_CODED) return makeUnitList(top);

  assert(ta->code!=NOT_CODED);
  assert(tb->code!=NOT_CODED);

  /**** Handle the general case: ****/
  /* At this point, both ta and tb have codes */

  Traceline("starting lub of %D and %D\n", ta, tb);

  /* Get the pattern to search for: */
  /* pattern = ta or tb */
  pattern = copyTypeCode(ta->code);
  or_codes(pattern, tb->code);

  Traceline("code of lub is %C\n", pattern);

  /* Flags is used to avoid checking types more than once: */
  flags = (long *)stack_alloc(sizeof(unsigned long) * (type_count+1));
  memset(flags, 0, sizeof(unsigned long) * (type_count+1));

  /* Now traverse all parents of ta and tb to get the lub: */
  ans = NULL;
 /* flags[bit_length(ta->code)]=TRUE; */ /* Don't return disjunction {ta;tb} ! */
 /* flags[bit_length(tb->code)]=TRUE; */
  { ptr_int_list a=ans;
    while(a) { Traceline("member of ans: %D\n",(ptr_definition)a->value); a=a->next; }
  }
  Traceline("start traverse %D (ta)\n", ta);
 check_and_traverse_parents(ta, &ans, pattern, flags);
  Traceline("end traverse %D (ta)\n", ta);
  { ptr_int_list a=ans;
    while(a) { Traceline("member of ans: %D\n",(ptr_definition)a->value); a=a->next; }
  }
  Traceline("start traverse %D (tb)\n", tb);
 check_and_traverse_parents(tb, &ans, pattern, flags);
  Traceline("end traverse %D (tb)\n", tb);
  { ptr_int_list a=ans;
    while(a) { Traceline("member of ans: %D\n",(ptr_definition)a->value); a=a->next; }
  }
  Traceline("start traverse %D (top)\n", top);
 check_and_traverse_parents(top, &ans, pattern, flags);
  Traceline("end traverse %D (top)\n", top);
  { ptr_int_list a=ans;
    while(a) { Traceline("member of ans: %D\n",(ptr_definition)a->value); a=a->next; }
  }

  assert(ans!=NULL);

  return ans;
}
